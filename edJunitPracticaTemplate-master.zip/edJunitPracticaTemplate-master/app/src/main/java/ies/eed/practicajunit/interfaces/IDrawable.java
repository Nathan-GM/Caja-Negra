package ies.eed.practicajunit.interfaces;

import javafx.scene.canvas.GraphicsContext;

public interface IDrawable {

    public void paint(GraphicsContext gc);
}
package ies.eed.practicajunit.interfaces;

public interface IWarnClock{
    public void TicTac();
}